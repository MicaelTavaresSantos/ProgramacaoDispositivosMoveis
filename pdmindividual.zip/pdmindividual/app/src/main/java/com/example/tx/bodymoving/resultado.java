package com.example.tx.bodymoving;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import android.view.View;
import android.widget.Button;
import android.widget.ListView;


public class resultado extends imcresultado {

    DatabaseHelper database = null;
    Button voltar,mostrar;
    @Override
    protected  void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultados);
        voltar=  (Button) findViewById(R.id.voltar);
        mostrar=  (Button) findViewById(R.id.mostrar);

        VoltarAtras();
        mostrarosdados();

    }
    private void VoltarAtras(){
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(a);
            }
        });
    }
    private void mostrarosdados(){
        mostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database = new DatabaseHelper(mostrar.getContext());
                new Handler().post(new Runnable() {
                    WeigthDatabaseAdapter weigthDatabaseAdapter;
                    ListView myList = (ListView) findViewById(android.R.id.list);

                    public void run() {
                        weigthDatabaseAdapter = new WeigthDatabaseAdapter(resultado.this, myDb.getAllData());
                        myList.setAdapter(weigthDatabaseAdapter);
                    }
                });
            }
        });
    }
}



