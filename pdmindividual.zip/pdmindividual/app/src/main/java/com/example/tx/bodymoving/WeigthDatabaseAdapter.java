package com.example.tx.bodymoving;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;



public class WeigthDatabaseAdapter  extends CursorAdapter{



    public WeigthDatabaseAdapter(Context context, Cursor c) {
        super(context, c);

    }


    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        LayoutInflater inflater= LayoutInflater.from(viewGroup.getContext());
        View generatedView = inflater.inflate(R.layout.list,viewGroup,false);
        return generatedView;

    }

    //Carrega os valores da base dados para as respetivas textviews
    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        TextView Nome = (TextView) view.findViewById(R.id.Nome);
        TextView Peso = (TextView) view.findViewById(R.id.Peso);
        TextView Imc = (TextView) view.findViewById(R.id.IMC);
        TextView Data = (TextView) view.findViewById(R.id.Data);
        TextView test = (TextView) view.findViewById(R.id.test);

        Data.setText("Data: "+cursor.getString(0));
        Nome.setText("Nome: "+cursor.getString(1));
        Peso.setText("Peso: "+cursor.getString(2));
        Imc.setText("IMC: "+cursor.getString(3));
        test.setText("\n");


    }
}
