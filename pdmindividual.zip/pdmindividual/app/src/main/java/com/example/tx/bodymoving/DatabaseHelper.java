package com.example.tx.bodymoving;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "IMC.db";
    public static final String TABLE_NAME = "bodymoving";
    public static final String COL_1 = "_id";
    public static final String COL_2 = "Nome";
    public static final String COL_3 = "PESO";
    public static final String COL_4 = "IMC";
    public static final String DATE_FORMAT="yyyy-MM-dd";
    SimpleDateFormat dbDateFormat= new SimpleDateFormat(DATE_FORMAT);

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +"( _id TEXT, Nome TEXT ,PESO FLOAT,IMC FLOAT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String Nome, Float peso, Float imc, Date date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,Nome);
        contentValues.put(COL_3,peso);
        contentValues.put(COL_4,imc);
        contentValues.put(COL_1,dbDateFormat.format(date));
        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM bodymoving WHERE _id >= date('now','-30 day') order by _id",null);
        db.delete("bodymoving","PESO"+"=0",new String[] {});


        return res;
    }






}