package com.example.tx.bodymoving;

import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;


public class imcresultado extends MainActivity {
    TextView tvResultado,tipoderesultado,timestamp;
    float altura,peso,resultado;
    String nome;
    String MuitoMagro = "Baixo Peso"; String Magro = "Magro"; String Normal = "Normal"; String Excesso = "Acima do Peso"; String Obeso = "Obeso";
    Button historico,voltar;
    DatabaseHelper myDb;
    DateFormat shortDateFormat=DateFormat.getDateInstance(DateFormat.SHORT, Locale.ENGLISH);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imcresultado);
        myDb = new DatabaseHelper(this);
        tvResultado= (TextView)findViewById(R.id.tvResultado);
        tipoderesultado= (TextView)findViewById(R.id.tipoderesultado);
        timestamp= (TextView)findViewById(R.id.timestamp);
        historico=  (Button) findViewById(R.id.historico);
        voltar=  (Button) findViewById(R.id.voltar);

        //Apanhar os valores da outra atividade
        Intent i=getIntent();
        nome=i.getStringExtra("nome");
        altura=i.getFloatExtra("altura", 0);
        peso=i.getFloatExtra("peso", 0);
        resultado=(float) (peso / Math.pow(altura, 2));

        VoltarAtras();
        viewAll();
        AddData();
        setColor();
    }
        public  void AddData() {

            tvResultado.setText(String.valueOf(resultado));
            Date curDate = new Date();
            String dataString = shortDateFormat.format(curDate);
            Intent i=getIntent();
            nome=i.getStringExtra("nome");
            altura=i.getFloatExtra("altura", 0);
            peso=i.getFloatExtra("peso", 0);

            boolean isInserted = myDb.insertData(String.valueOf(nome),Float.valueOf(peso),
                    Float.valueOf(resultado),curDate);

        }
    public void viewAll() {
        historico.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(imcresultado.this,resultado.class);
                        startActivity(intent);
                        finish();
                    }
                }
        );
    }
    private void setColor(){
        if (resultado < 16) {
            tipoderesultado.setText(String.valueOf(MuitoMagro));
            tipoderesultado.setTextColor(Color.RED);
        } else if (resultado < 18.5) {
            tipoderesultado.setTextColor(Color.YELLOW);
            tipoderesultado.setText(String.valueOf(Magro));
        } else if (resultado < 25) {
            tipoderesultado.setTextColor(Color.GREEN);
            tipoderesultado.setText(String.valueOf(Normal));
        } else if (resultado < 30) {
            tipoderesultado.setTextColor(Color.YELLOW);
            tipoderesultado.setText(Excesso);
        } else {
            tipoderesultado.setTextColor(Color.RED);
            tipoderesultado.setText(Obeso);
        }

    }
    private void VoltarAtras(){
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(a);
            }
        });
    }



    @Override
    public void onStart() {
        super.onStart();


    }

    @Override
    public void onStop() {
        super.onStop();


    }


    public void onResume()
    {
        super.onResume();

    }

    public void onPause()
    {
        super.onPause();

    }

    public void onRestart()
    {
        super.onRestart();

    }
    }

