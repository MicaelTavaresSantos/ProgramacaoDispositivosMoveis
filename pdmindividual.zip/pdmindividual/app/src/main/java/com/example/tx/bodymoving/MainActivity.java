package com.example.tx.bodymoving;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.support.v7.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    float peso , altura ;
    String nome;
    EditText Peso,Altura,Nome;
    Button historico;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Peso = (EditText) findViewById(R.id.Peso);
        Altura = (EditText) findViewById(R.id.Altura);
        Nome = (EditText) findViewById(R.id.Nome);
        historico=  (Button) findViewById(R.id.historico);
        VoltarAtras();

    }


    //Metodo que apanha os valores do peso e da altura e manda os para a próxima atividade para fazer o
    // calculo e apresentar o resultado.
    public void Calcular(View v) {

        try {
            peso = Float.parseFloat(Peso.getText().toString());
            altura = Float.parseFloat(Altura.getText().toString());
            nome = String.format(Nome.getText().toString());
            Intent i = new Intent(this, imcresultado.class);
            i.putExtra("nome",nome);
            i.putExtra("peso", peso);
            i.putExtra("altura", altura);
            startActivity(i);

        } catch (Exception e) {
            Toast.makeText(this, "Erro nos dados inseridos", Toast.LENGTH_SHORT).show();

        }
    }
    private void VoltarAtras(){
        historico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplicationContext(), resultado.class);
                startActivity(a);
            }
        });
    }



    @Override
    protected void onStop(){
        super.onStop();
    }
    public void onStart()
    {
        super.onStart();

    }
    public void onResume()
    {
        super.onResume();

    }

    public void onPause()
    {
        super.onPause();

    }

    public void onRestart()
    {
        super.onRestart();

    }
}



